# CodeAlpha_StudentGradeTracker

**Task 1 — Student Grade Tracker** (CodeAlpha Java Programming Internship)

A console-based Java application to input and manage student grades, calculate
average/highest/lowest scores, and display a summary report.

## Features
- Add students with multiple subject scores (stored in an `ArrayList`)
- View all students in a formatted table (average, highest, lowest, letter grade)
- Class-wide summary report (class average, top performer, needs improvement)
- Search a student by name
- Delete a student record
- **Persistence**: all data is saved to `students.txt` (plain text/CSV) via File I/O,
  and automatically reloaded the next time the program runs

## How to Compile & Run
```bash
cd src
javac StudentGradeTracker.java
java StudentGradeTracker
```

## Tech Used
- Core Java (OOP)
- `ArrayList`, Java Streams (for average/max/min calculations)
- File I/O (`BufferedReader` / `PrintWriter`) for persistence

## Sample Menu
```
1. Add Student & Grades
2. View All Students
3. Summary Report (Average/Highest/Lowest)
4. Search Student by Name
5. Delete Student
6. Save Data Now
0. Exit
```
