# CodeAlpha_StockTradingPlatform

**Task 2 — Stock Trading Platform** (CodeAlpha Java Programming Internship)

A console-based simulation of a basic stock trading environment built with
Object-Oriented Programming: `Stock`, `Market`, `User`, `Portfolio`, and
`Transaction` classes work together to model buying/selling shares and
tracking portfolio performance.

## Features
- View live-ish market data for 6 sample stocks (AAPL, GOOG, AMZN, TSLA, MSFT, INFY)
- Buy / sell shares (validates funds and share ownership before executing)
- Portfolio view showing quantity, current price, and total value per holding
- Full transaction history log (buy/sell records)
- "Advance Market" option simulates a price tick (random walk, ±5%) so you can
  see gains/losses over time
- **Persistence**: cash balance, holdings, and transaction history are saved
  to `portfolio.txt` via File I/O and reloaded on the next run

## How to Compile & Run
```bash
cd src
javac StockTradingPlatform.java
java StockTradingPlatform
```

## Tech Used
- Core Java (OOP: Stock, Market, User, Portfolio, Transaction classes)
- Collections (`Map`, `LinkedHashMap`, `List`)
- File I/O for persisting portfolio state across sessions

## Sample Menu
```
1. View Market Data
2. Buy Stock
3. Sell Stock
4. View My Portfolio
5. View Transaction History
6. Advance Market (simulate price changes)
7. Save Portfolio Now
0. Exit
```

## Note
This is an educational simulation — prices are randomly generated and no real
money or real market data is involved.
