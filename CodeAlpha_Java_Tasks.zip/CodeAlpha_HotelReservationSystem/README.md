# CodeAlpha_HotelReservationSystem

**Task 4 — Hotel Reservation System** (CodeAlpha Java Programming Internship)

A console-based system to search, book, and manage hotel rooms, with room
categorization, reservation/cancellation, a payment simulation, and full
booking-detail views.

## Features
- 10 pre-loaded rooms across 3 categories: **Standard** ($60/night),
  **Deluxe** ($110/night), **Suite** ($220/night)
- Search available rooms by category
- Book a room: enter guest name + number of nights, see cost breakdown, then
  confirm through a simulated payment step (generates a confirmation code)
- Cancel a reservation by ID (automatically frees up the room again)
- View full details of any reservation by ID, or list all active reservations
- **Persistence**: room availability and all reservations are saved to
  `hotel_data.txt` via File I/O and reloaded on the next run

## How to Compile & Run
```bash
cd src
javac HotelReservationSystem.java
java HotelReservationSystem
```

## Tech Used
- Core Java (OOP: `Room`, `Reservation`, `Hotel` classes, `RoomCategory` enum)
- Collections (`TreeMap` for rooms, `LinkedHashMap` for reservations)
- File I/O for persisting rooms and bookings across sessions

## Sample Menu
```
1. View All Rooms
2. Search Available Rooms by Category
3. Book a Room
4. Cancel Reservation
5. View Reservation Details
6. View All Reservations
7. Save Data Now
0. Exit
```
